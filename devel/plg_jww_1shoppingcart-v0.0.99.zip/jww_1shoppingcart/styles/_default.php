<?php 
/**
 * @version $Id$
 * @package jww_1shoppingcart
 * @author John Wicks
 * @copyright Copyright (C) 2010 JWWicks. All rights reserved.
 * @license GNU/GPL
 *
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

?>